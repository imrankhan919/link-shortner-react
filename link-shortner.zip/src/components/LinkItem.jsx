import React from "react";

const LinkItem = ({ link }) => {
  return (
    <div className="border bg-white rounded-md p-3 flex items-center justify-between my-2">
      <a href={link.data} target="_blank" className="text-blue-800">
        {link.data}
      </a>
      <button className="bg-blue-400 py-1 px-3 rounded-md">
        <a href={link.data} className="text-sm text-white font-bold">
          Visit
        </a>
      </button>
    </div>
  );
};

export default LinkItem;
