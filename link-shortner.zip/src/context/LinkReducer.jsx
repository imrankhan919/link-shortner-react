const LinkReducer = (state, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default LinkReducer;
